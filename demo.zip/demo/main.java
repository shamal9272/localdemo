public class ABC{
 void sound(){   
 System.out.println(" I am in class ABC ")
}
}
public class XYZ extends ABC{
 void bark(){
 System.out.println(" I am in class XYZ ")
}
}
class main{
 public static void main (string[] args){
    XYZ obj = new ABC();
    obj.sound();
    obj.bark();
}